import tkinter as tk
from tkinter import ttk
import time
import threading
from playsound import playsound


# ==========================
# DATOS DEL QUIZ
# ==========================

preguntas = [
    {
        "pregunta": "1. ¿Qué es lo más seguro para crear una contraseña?",
        "opciones": ["Usar tu fecha de nacimiento", "Usar 123456", "Usar combinación de letras, números y símbolos"],
        "correcta": 2,
        "consejo": "Siempre usa contraseñas largas y con diferentes tipos de caracteres."
    },
    {
        "pregunta": "2. ¿Qué debes hacer si un correo te pide tu contraseña?",
        "opciones": ["Responder rápido", "Verificar si es phishing", "Mandar tu contraseña"],
        "correcta": 1,
        "consejo": "Nunca envíes contraseñas. Revisa remitentes y enlaces."
    },
    {
        "pregunta": "3. ¿Cuál es la mejor forma de proteger tus redes sociales?",
        "opciones": ["Reutilizar contraseñas", "Usar autenticación en dos pasos", "Dejar todo público"],
        "correcta": 1,
        "consejo": "Activa 2FA siempre para impedir accesos no autorizados."
    },
    {
        "pregunta": "4. ¿Qué debes hacer cuando usas WiFi público?",
        "opciones": ["Entrar al banco", "Usar VPN", "Compartir archivos"],
        "correcta": 1,
        "consejo": "Las redes públicas son inseguras, usa VPN."
    },
    {
        "pregunta": "5. ¿Qué acción es segura en internet?",
        "opciones": ["Descargar archivos desconocidos", "Dar clic a cualquier enlace", "Verificar URLs antes de entrar"],
        "correcta": 2,
        "consejo": "Siempre revisa enlaces antes de abrirlos."
    }
]


# ==========================
# SONIDOS Y MÚSICA
# ==========================

import pygame

# Inicializa pygame mixer
pygame.mixer.init()

def reproducir_musica():
    pygame.mixer.music.load("Tower of London.mp3")
    pygame.mixer.music.set_volume(0.1)   # 🎚️ Volumen música (0.0 a 1.0)
    pygame.mixer.music.play(-1)  # Loop infinito

def sonido_click():
    sonido = pygame.mixer.Sound("Mouse Click Sound Effect.mp3")
    sonido.set_volume(0.8)  
    sonido.play()

def sonido_correcto():
    sonido = pygame.mixer.Sound("Correct Sound Effect.mp3")
    sonido.set_volume(0.5)  
    sonido.play()

def sonido_error():
    sonido = pygame.mixer.Sound("Loud Incorrect Buzzer Lie  MemeSound Effect.mp3")
    sonido.set_volume(1.0)  
    sonido.play()

# ==========================
# FUNCIONES DEL QUIZ
# ==========================

indice = 0
score = 0

def animar_fade(widget):
    for i in range(0, 11):
        alpha = i / 10
        widget.configure(fg=f"#{int(200*alpha):02x}{int(200*alpha):02x}{int(200*alpha):02x}")
        ventana.update()
        time.sleep(0.02)

def actualizar_pregunta():
    global indice

    if indice >= len(preguntas):
        mostrar_resultado()
        return

    pregunta_lbl.config(text=preguntas[indice]["pregunta"])
    for i, btn in enumerate(botones):
        btn.config(text=preguntas[indice]["opciones"][i])

    progreso["value"] = (indice / len(preguntas)) * 100
    animar_fade(pregunta_lbl)

def verificar_respuesta(op):
    global indice, score

    sonido_click()

    correcta = preguntas[indice]["correcta"]

    if op == correcta:
        score += 1
        sonido_correcto()
    else:
        sonido_error()

    mostrar_consejo(preguntas[indice]["consejo"])

    indice += 1
    ventana.after(1000, actualizar_pregunta)

def mostrar_consejo(texto):
    consejo_lbl.config(text="💡 Consejo: " + texto)
    animar_fade(consejo_lbl)

def mostrar_resultado():
    for btn in botones:
        btn.pack_forget()

    pregunta_lbl.config(text=f"🎉 ¡Completaste el Quiz! Puntuación: {score}/5\n\nGracias por participar.")

    consejo_lbl.config(text="")
    progreso["value"] = 100


# ==========================
# INTERFAZ GRÁFICA DARK MODE
# ==========================

ventana = tk.Tk()
ventana.title("Quiz de Ciberseguridad")
ventana.geometry("650x500")
ventana.configure(bg="#1e1e1e")

estilo = ttk.Style()
estilo.theme_use("clam")
estilo.configure("TProgressbar", troughcolor="#333333", background="#00bfff", thickness=20)


titulo = tk.Label(ventana, text="🔐 Quiz de Ciberseguridad", font=("Arial", 22, "bold"), fg="#00bfff", bg="#1e1e1e")
titulo.pack(pady=20)

pregunta_lbl = tk.Label(ventana, text="", font=("Arial", 16), fg="#CCCCCC", bg="#1e1e1e", wraplength=600)
pregunta_lbl.pack(pady=20)

botones = []
for i in range(3):
    btn = tk.Button(
        ventana,
        text="",
        font=("Arial", 14),
        bg="#333333",
        fg="#FFFFFF",
        activebackground="#00bfff",
        activeforeground="#000",
        width=40,
        command=lambda x=i: verificar_respuesta(x)
    )
    btn.pack(pady=5)
    botones.append(btn)

progreso = ttk.Progressbar(ventana, length=500, mode="determinate")
progreso.pack(pady=20)

consejo_lbl = tk.Label(ventana, text="", font=("Arial", 13), fg="#AAAAAA", bg="#1e1e1e", wraplength=600)
consejo_lbl.pack(pady=10)

# Iniciar música en hilo separado
threading.Thread(target=reproducir_musica, daemon=True).start()

actualizar_pregunta()

ventana.mainloop()
